from pyrogram import filters, Client
import asyncio

from pyrogram.methods import messages
from helpers.pyrohelper import get_arg, denied_users
import helpers.mongo.pmpermitdb as ᴘʏᴛʜᴏɴɪᴄ

FLOOD_CTRL = 0
ALLOWED = []
USERS_AND_WARNS = {}




@Client.on_message(filters.command("setlimit", ["."]) & filters.me)
async def pmguard(client, message):
    arg = get_arg(message)
    if not arg:
        await message.edit("**Set limit to what?**")
        return
    await ᴘʏᴛʜᴏɴɪᴄ.set_limit(int(arg))
    await message.edit(f"**Limit set to {arg}**")


@Client.on_message(filters.command("setpmmsg", ["."]) & filters.me)
async def setpmmsg(client, message):
    arg = get_arg(message)
    if not arg:
        await message.edit("**What message to set**")
        return
    if arg == "default":
        await ᴘʏᴛʜᴏɴɪᴄ.set_permit_message(ᴘʏᴛʜᴏɴɪᴄ.PMPERMIT_MESSAGE)
        await message.edit("**Anti_PM message set to default**.")
        return
    await ᴘʏᴛʜᴏɴɪᴄ.set_permit_message(f"`{arg}`")
    await message.edit("**Custom anti-pm message set**")


@Client.on_message(filters.command("setblockmsg", ["."]) & filters.me)
async def setpmmsg(client, message):
    arg = get_arg(message)
    if not arg:
        await message.edit("**What message to set**")
        return
    if arg == "default":
        await ᴘʏᴛʜᴏɴɪᴄ.set_block_message(ᴘʏᴛʜᴏɴɪᴄ.BLOCKED)
        await message.edit("**Block message set to default**.")
        return
    await ᴘʏᴛʜᴏɴɪᴄ.set_block_message(f"`{arg}`")
    await message.edit("**Custom block message set**")


@Client.on_message(filters.command(["allow", "ap", "approve", "a"], ["."]) & filters.me & filters.private)
async def allow(client, message):
    chat_id = message.chat.id
    pmpermit, pm_message, limit, block_message = await ᴘʏᴛʜᴏɴɪᴄ.get_pm_settings()
    await ᴘʏᴛʜᴏɴɪᴄ.allow_user(chat_id)
    await message.edit(f"**I have allowed [you](tg://user?id={chat_id}) to PM me.**")
    async for message in app.search_messages(
        chat_id=message.chat.id, query=pm_message, limit=1, from_user="me"
    ):
        await message.delete()
    USERS_AND_WARNS.update({chat_id: 0})


@Client.on_message(filters.command(["deny", "dap", "disapprove", "dapp"], ["."]) & filters.me & filters.private)
async def deny(client, message):
    chat_id = message.chat.id
    await Zectdb.deny_user(chat_id)
    await message.edit(f"**I have denied [you](tg://user?id={chat_id}) to PM me.**")


@Client.on_message(
    filters.private
    & filters.create(denied_users)
    & filters.incoming
    & ~filters.service
    & ~filters.me
    & ~filters.bot
)
async def reply_pm(app: Client, message):
    global FLOOD_CTRL
    pmpermit, pm_message, limit, block_message = await ᴘʏᴛʜᴏɴɪᴄ.get_pm_settings()
    user = message.from_user.id
    user_warns = 0 if user not in USERS_AND_WARNS else USERS_AND_WARNS[user]
    if user_warns <= limit - 2:
        user_warns += 1
        USERS_AND_WARNS.update({user: user_warns})
        if not FLOOD_CTRL > 0:
            FLOOD_CTRL += 1
        else:
            FLOOD_CTRL = 0
            return
        async for message in app.search_messages(
            chat_id=message.chat.id, query=pm_message, limit=1, from_user="me"
        ):
            await message.delete()
        await message.reply(pm_message, disable_web_page_preview=True)
        return
    await message.reply(block_message, disable_web_page_preview=True)
    await app.block_user(message.chat.id)
    USERS_AND_WARNS.update({user: 0})